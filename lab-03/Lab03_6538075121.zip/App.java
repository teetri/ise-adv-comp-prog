import door.*;

public class App {
    public static void main(String[] args) throws Exception {
        DoorTest.main(args);
    }
}
